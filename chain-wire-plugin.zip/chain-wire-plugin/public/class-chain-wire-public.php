<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://chainwire.org
 * @since      1.0.0
 *
 * @package    ChainWire
 * @subpackage ChainWire/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    ChainWire
 * @subpackage ChainWire/public
 * @author     Your Name <konrad@cracsoft.com>
 */
class ChainWirePublic
{

    const StatusError = 'ERROR';
    const StatusSuccess = 'SUCCESS';

    /**
     * Enable iframes with videos of post
     *
     * @param $allowedposttags
     * @return mixed
     */
    public function esw_author_cap_filter($allowedposttags)
    {
        $allowedposttags['iframe'] = array(
            'align' => true,
            'width' => true,
            'height' => true,
            'frameborder' => true,
            'name' => true,
            'src' => true,
            'id' => true,
            'class' => true,
            'style' => true,
            'scrolling' => true,
            'marginwidth' => true,
            'marginheight' => true,
            'allowfullscreen' => true,
            'mozallowfullscreen' => true,
            'webkitallowfullscreen' => true,
        );
        return $allowedposttags;
    }

    private $domain = 'https://app.chainwire.org/';
    private $author_username = 'chainwire';
    private $author_email = 'contact@chainwire.org';
    private $author_first_name = 'ChainWire';
    private $author_url = 'https://chainwire.org/';
    private $author_last_name = null;
    private $author_twitter = null;
    private $author_facebook = null;
    private $author_google = null;
    private $author_tumblr = null;
    private $author_instagram = null;
    private $author_pinterest = null;
    private $verify_post = true;

    private $author_avatar = '/wp-plugin/author_avatar.png';

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $chain_wire_plugin The ID of this plugin.
     */
    private $chain_wire_plugin;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $version The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @param string $chain_wire_plugin The name of the plugin.
     * @param string $version The version of this plugin.
     * @since    1.0.0
     */
    public function __construct($chain_wire_plugin, $version)
    {

        $this->chain_wire_plugin = $chain_wire_plugin;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in ChainWireLoader as all of the hooks are defined
         * in that particular class.
         *
         * The ChainWireLoader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->chain_wire_plugin, plugin_dir_url(__FILE__) . 'css/chain-wire-public.css', array(), $this->version, 'all');

    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in ChainWireLoader as all of the hooks are defined
         * in that particular class.
         *
         * The ChainWireLoader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->chain_wire_plugin, plugin_dir_url(__FILE__) . 'js/chain-wire-public.js', array('jquery'), $this->version, false);

    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function custom_rest_api_init()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in ChainWireLoader as all of the hooks are defined
         * in that particular class.
         *
         * The ChainWireLoader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        register_rest_route('chain-wire-plugin/v1', '/posts', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_new_post')
        ));

        register_rest_route('chain-wire-plugin/v1', '/verification', array(
            'methods' => 'POST',
            'callback' => array($this, 'verify_installation')
        ));

    }

    /**
     * @param $plugin_token
     * @param $plugin_secret
     * @param $article_id
     * @param $press_release_html
     * @param null $verification_token
     * @return bool
     */
    protected function verify_article($plugin_token, $plugin_secret, $article_id, $press_release_html, $verification_token = null)
    {
        $content_hash = md5($press_release_html);
        $response = $this->send_post_request([
            'form' => [
                'article_id' => $article_id,
                'press_release_html_hash' => $content_hash,
                'verification_token' => $verification_token
            ]
        ]);

        if (!is_wp_error($response)) {
            if ($response['response']['code'] == 200) {
                $data = json_decode($response['body']);
                if ($data->data->hash === crc32($content_hash . $plugin_token . $plugin_secret)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param $url
     * @return bool|mixed
     */
    protected function download_file($url)
    {
        if (!class_exists('WP_Http')) {
            include_once(ABSPATH . WPINC . '/class-http.php');
        }
        $http = new WP_Http();
        $response = $http->request($url);
        if (is_wp_error($response) || $response['response']['code'] !== 200) {
            return false;
        }
        $upload = wp_upload_bits(basename($url), null, $response['body']);
        if (!empty($upload['error'])) {
            return false;
        }
        return $upload;
    }

    /**
     * @param $url
     * @return array
     */
    protected function get_fixed_url($url)
    {
        $src = $url;
        $attachment_id = null;
        if (!$this->is_absolute($url)) {
            $src = $this->domain . $url;
        }
        $upload = $this->download_file($src);
        if ($upload && $upload['url']) {
            $src = $upload['url'];
        }
        if ($upload['file']) {
            $attachment_id = $this->set_attachment($upload['file']);
        }
        return [
            'url' => $src,
            'attachment_id' => $attachment_id
        ];
    }

    /**
     * @param $file
     * @param null $parent_post_id
     * @return int|WP_Error
     */
    protected function set_attachment($file, $parent_post_id = null)
    {
        $filename = basename($file);
        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_parent' => $parent_post_id,
            'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attachment_id = wp_insert_attachment($attachment, $file, $parent_post_id);
        if (!is_wp_error($attachment_id)) {
            require_once(ABSPATH . "wp-admin" . '/includes/image.php');
            $attachment_data = wp_generate_attachment_metadata($attachment_id, $file);
            wp_update_attachment_metadata($attachment_id, $attachment_data);
        }
        return $attachment_id;
    }

    /**
     * @param $url
     * @return false|int
     */
    protected static function is_absolute($url)
    {
        return preg_match('/^https?:\/\/(.*)/', $url);
    }

    /**
     * @return false|int|WP_Error
     * @throws Exception
     */
    protected function get_author_id()
    {
        $username = $this->author_username;
        $user_id = username_exists($username);
        $user_email = $this->author_email;
        if (!$user_id) {
            if (email_exists($user_email)) {
                throw new Exception('User already exists.');
            }
            $random_password = wp_generate_password($length = 12, $include_standard_special_chars = false);
            $user_id = wp_create_user($username, $random_password, $user_email);

            $this->set_avatar_for_user($this->domain . $this->author_avatar, $user_id);

            $user = new WP_User($user_id);
            $user->set_role('author');

            $arr = [
                'ID' => $user_id, // this is the ID of the user you want to update.
                'first_name' => $this->author_first_name,
                'last_name' => $this->author_last_name,
                'user_url' => $this->author_url,
                'twitter' => $this->author_twitter,
                'facebook' => $this->author_facebook,
                'google' => $this->author_google,
                'tumblr' => $this->author_tumblr,
                'instagram' => $this->author_instagram,
                'pinterest' => $this->author_pinterest,
            ];
            foreach ($arr as $k => $v) {
                if ($v === null) {
                    delete_user_meta($user_id, $k);
                }
            }
            wp_update_user($arr);
        }

        return $user_id;
    }

    /**
     * @param $avatar_url
     * @param $user_id
     */
    protected function set_avatar_for_user($avatar_url, $user_id)
    {
        global $wpdb;
        $upload = $this->download_file($avatar_url);
        if ($upload['file']) {
            $attachment_id = $this->set_attachment($upload['file']);
            if ($attachment_id) {
                update_user_meta($user_id, $wpdb->get_blog_prefix() . 'user_avatar', $attachment_id);
            }
        }
    }

    /**
     * @param $categories
     * @return array
     */
    protected function get_categories($categories, $create_parent = false)
    {
        if (!$categories || !is_array($categories)) {
            $categories = [];
        }

        $connected = [];

        if ($create_parent) {
            $parent_category_name = 'ChainWire';
            $parent_category_id = get_cat_ID($parent_category_name);

            if (!$parent_category_id) {
                $parent = wp_insert_term($parent_category_name, 'category');
                if (!is_wp_error($parent)) {
                    $parent_category_id = $parent['term_id'];
                }
            }

            if ($parent_category_id) {
                foreach ($categories as $category) {
                    $c = get_cat_ID($category);
                    if (!$c) {
                        $c = wp_insert_term($category, 'category', ['parent' => $parent_category_id]);
                        if (!is_wp_error($c)) {
                            $connected[] = $c['term_id'];
                        }
                    } else {
                        $connected[] = $c;
                    }
                }
                if (count($categories) === 0) {
                    $connected = [$parent_category_id];
                }
            }
        } else {
            foreach ($categories as $category) {
                $c = get_cat_ID($category);
                if (!$c) {
                    $c = wp_insert_term($category, 'category');
                    if (!is_wp_error($c)) {
                        $connected[] = $c['term_id'];
                    }
                } else {
                    $connected[] = $c;
                }
            }
        }
        return $connected;
    }

    protected function add_iframe($initArray)
    {
        $initArray['extended_valid_elements'] = "iframe[id|class|title|style|align|frameborder|height|longdesc|marginheight|marginwidth|name|scrolling|src|width]";
        return $initArray;
    }

    protected function verify_image_url($url)
    {
        if (!$url) {
            return null;
        }
        $supported_images = array(
            'gif',
            'jpg',
            'jpeg',
            'png'
        );
        $ext = strtolower(pathinfo($url, PATHINFO_EXTENSION)); // Using strtolower to overcome case sensitive
        return in_array($ext, $supported_images) ? $url : null;
    }


    /**
     * @param $html
     * @param array $options
     * @return array
     */
    protected function regenerate_html($html, $options = [])
    {
        $add_feature_image_to_post = $options['add_feature_image_to_post'];
        $use_client_image_for_featured_image = $options['use_client_image_for_featured_image'];
        $press_release_client_image = $options['press_release_client_image'];
        $press_release_featured_image = $options['press_release_featured_image'];
        $uploaded_feature_image = null;
        $uploaded_client_image = null;

        $press_release_client_image = $this->verify_image_url($press_release_client_image);
        $press_release_featured_image = $this->verify_image_url($press_release_featured_image);

        if ($use_client_image_for_featured_image && $press_release_client_image) {
            $uploaded_client_image = $this->get_fixed_url($press_release_client_image);
        }

        if ($press_release_featured_image) {
            $uploaded_feature_image = $this->get_fixed_url($press_release_featured_image);
        }

        $feature_image = $uploaded_client_image ? $uploaded_client_image : $uploaded_feature_image;

        $doc = new DOMDocument();
        if ($add_feature_image_to_post && $feature_image) {
            $src = $feature_image['url'];
            $attachment_id = $feature_image['attachment_id'];
            $src_set = null;
            if ($src) {
                if ($attachment_id) {
                    $src_set = wp_get_attachment_image_srcset($attachment_id);
                }
                $src_set_attribute = $src_set ? ' srcset="' . $src_set . '"' : '';
                $html = '<p><img alt="" src="' . $src . '"' . $src_set_attribute . '></p>' . $html;
            }
        }

        $doc->loadHTML('<meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . $html);
        $tags = $doc->getElementsByTagName('img');

        /** @var DOMNode $tag */
        foreach ($tags as $tag) {
            $img = $tag->getAttribute('src');
            $fixed_url = $this->get_fixed_url($img);
            $src = $fixed_url['url'];
            $attachment_id = $fixed_url['attachment_id'];
            if ($src) {
                if ($attachment_id) {
                    $src_set = wp_get_attachment_image_srcset($attachment_id);
                    if ($src_set) {
                        $tag->setAttribute('src_set', $src_set);
                    }
                    $src_large = wp_get_attachment_image_url($attachment_id, 'large');
                    $tag->setAttribute('src', $src_large);
                }
            }
        }

        return [
            'html' => $doc->saveHTML(),
            'feature_image' => $feature_image
        ];
    }

    /**
     * @param $data
     * @return array|WP_Error
     */
    protected function send_post_request($data)
    {
        $url = $this->domain . '/api/wp-plugin/verify-article';
        $response = wp_remote_post($url, array(
                'method' => 'POST',
                'timeout' => 45,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking' => true,
                'headers' => array(),
                'body' => $data,
                'cookies' => array()
            )
        );
        return $response;
    }

    /**
     * @return string
     * @throws Exception
     */
    protected function get_current_date()
    {
        $now = new DateTime();
        return $now->format('Y-m-d H:i:s');
    }

    public function add_new_post()
    {
        return $this->publish_new_post([
            'post_status' => 'publish'
        ]);
    }

    /**
     * @param $field
     * @param null $default_value
     * @return mixed
     */
    protected function get_safe_html_field($field, $default_value = null)
    {
        $allowed_tags = '<br><strong><bold><b><i><ol><li><ul><a><img><video><h1><code><h2><h3><h4><h5><h6><p><blockquote><u><del><span><iframe>';
        $field = isset($_POST[$field]) ? $_POST[$field] : $default_value;
        if ($field) {
            return wp_kses($field, array(
                'br' => array(),
                'strong' => array(),
                'bold' => array(),
                'b' => array(),
                'i' => array(),
                'ol' => array(),
                'ul' => array(),
                'li' => array(),
                'a' => array(
                    'href' => array(),
                    'title' => array(),
                    'target' => array(),
                    'rel' => array(),
                ),
                'img' => array(
                    'src' => array(),
                    'alt' => array(),
                ),
                'video' => array(),
                'h1' => array(),
                'h2' => array(),
                'h3' => array(),
                'h4' => array(),
                'h5' => array(),
                'h6' => array(),
                'p' => array(),
                'blockquote' => array(),
                'u' => array(),
                'del' => array(),
                'span' => array(),
                'iframe' => array(),
            ));
        }
        return $field;
    }

    /**
     * @param $field
     * @param null $default_value
     * @return mixed
     */
    protected function get_safe_post_field($field, $default_value = null)
    {
        return sanitize_text_field(isset($_POST[$field]) ? $_POST[$field] : $default_value);
    }

    /**
     * @param $field
     * @param null $default_value
     * @return mixed
     */
    protected function get_safe_option($options, $field, $default_value = null)
    {
        return sanitize_text_field(isset($options[$field]) ? $options[$field] : $default_value);
    }

    public function verify_installation()
    {
        $verification_kind = $this->get_safe_post_field('verification_kind', 'installation');
        $data = $this->publish_new_post([
            'post_status' => 'draft'
        ]);
        if ($verification_kind === 'installation') {
            if ($data['status'] === self::StatusSuccess) {
                $post_data = $data['data'];
                $post_id = $post_data['post_id'];
                if ($post_id) {
                    wp_delete_post($post_id, true);
                }
            }
        }
        return $data;
    }

    /**
     * @return array
     * @throws Exception
     */
    protected function publish_new_post($publish_options = [])
    {
        $post_status = isset($publish_options['post_status']) ? $publish_options['post_status'] : 'publish';

        try {
            $token = $this->get_safe_post_field('token');
            if ($token) {
                $options = get_option($this->chain_wire_plugin);
                $plugin_token = $this->get_safe_option($options, 'token');
                $plugin_secret = $this->get_safe_option($options, 'secret');
                $custom_category = $this->get_safe_option($options, 'category');
                $add_feature_image_to_post = $this->get_safe_option($options, 'add_feature_image_to_post');
                $use_client_image_for_featured_image = $this->get_safe_option($options, 'use_client_image_for_featured_image');
                $additional_categories = $this->get_safe_option($options, 'additional_categories', '');
                $additional_categories = explode(';', (string)$additional_categories);

                if ($plugin_token && $plugin_secret && $plugin_token === $token) {
                    $article_id = $this->get_safe_post_field('article_id');
                    $title = $this->get_safe_post_field('press_release_title');
                    $press_release_featured_image = $this->get_safe_post_field('press_release_featured_image');
                    $press_release_client_image = $this->get_safe_post_field('press_release_client_image');

                    $html = $this->get_safe_html_field('press_release_html');
                    $categories = $this->get_safe_post_field('press_release_categories', []);
                    $tags = $this->get_safe_post_field('press_release_tags', []);

                    $date = $this->get_safe_post_field('press_release_date', $this->get_current_date());
                    $verification_token = $this->get_safe_post_field('verification_token');

                    $verified = $this->verify_post ? $this->verify_article($plugin_token, $plugin_secret, $article_id, $html, $verification_token) : true;

                    $author_id = $this->get_author_id();
                    $html_fixed = $this->regenerate_html($html, [
                        'add_feature_image_to_post' => $add_feature_image_to_post,
                        'use_client_image_for_featured_image' => $use_client_image_for_featured_image,
                        'press_release_featured_image' => $press_release_featured_image,
                        'press_release_client_image' => $press_release_client_image
                    ]);
                    $categories = $this->get_categories($custom_category ? [$custom_category] : $categories);
                    $categories_additional = [];
                    if ($additional_categories) {
                        $categories_additional = $this->get_categories($additional_categories);
                        if (!$custom_category) {
                            $categories = [];
                        }
                    }
                    $categories = array_merge($categories, $categories_additional);

                    if ($verified) {
                        $my_post = array(
                            'post_title' => $title,
                            'post_content' => $html_fixed['html'],
                            'post_date' => $date,
                            'post_status' => $post_status,
                            'post_author' => $author_id,
                            'post_category' => $categories
                        );

                        $post_id = wp_insert_post($my_post);
                        wp_set_post_tags($post_id, $tags);

                        $link = get_permalink($post_id);
                        $date = get_the_date('c', $post_id);

                        if ($html_fixed['feature_image'] && $html_fixed['feature_image']['attachment_id']) {
                            set_post_thumbnail($post_id, $html_fixed['feature_image']['attachment_id']);
                        }

                        return [
                            'status' => self::StatusSuccess,
                            'data' => [
                                'html' => $html,
                                'html_fixed' => $html_fixed,
                                'post_id' => $post_id,
                                'article_url' => $link,
                                'published_at' => $date,
                                'options' => $options
                            ]
                        ];
                    } else {
                        throw new Exception('Wrong verification');
                    }
                } else {
                    throw new Exception('Wrong token');
                }
            }
        } catch (Exception $e) {
            return [
                'status' => self::StatusError,
                'errors' => [
                    'form' => $e->getMessage()
                ]
            ];
        }

        return [
            'status' => self::StatusError,
            'errors' => [
                'form' => 'Wrong Data'
            ]
        ];
    }

}
