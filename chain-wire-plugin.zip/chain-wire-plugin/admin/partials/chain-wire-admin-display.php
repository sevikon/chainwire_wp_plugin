<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://chainwire.org
 * @since      1.0.0
 *
 * @package    ChainWire
 * @subpackage ChainWire/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>

    <form method="post" name="cleanup_options" action="options.php">

        <?php
        //Grab all options
        $options = get_option($this->chain_wire_plugin);

        $categories = get_categories(array(
            "hide_empty" => 0,
            "type" => "post",
            'orderby' => 'name',
            'order' => 'ASC'
        ));

        function get_plugin_internal_option($options, $name, $default_value = null)
        {
            $option_value = $options[$name];
            return sanitize_text_field($option_value !== null ? $option_value : $default_value);
        }

        // Cleanup
        $token = get_plugin_internal_option($options, 'token');
        $secret = get_plugin_internal_option($options, 'secret');
        $category = get_plugin_internal_option($options, 'category');
        $post_status = get_plugin_internal_option($options, 'post_status', 'publish');
        $use_client_image_for_featured_image = get_plugin_internal_option($options, 'use_client_image_for_featured_image', false);
        $add_feature_image_to_post = get_plugin_internal_option($options, 'add_feature_image_to_post', false);
        $additional_categories = get_plugin_internal_option($options, 'additional_categories', '');

        $category_options = '';
        foreach ($categories as $c) {
            $category_options .= '<option value="' . $c->name . '" ' . ($c->name === $category ? 'selected="selected"' : '') . '>' . $c->name . '</option>';
        }

        $post_status_array = [
            [
                'name' => 'publish',
                'label' => 'Publish'
            ],
            [
                'name' => 'draft',
                'label' => 'Draft'
            ],
            [
                'name' => 'pending',
                'label' => 'Pending'
            ],
            [
                'name' => 'private',
                'label' => 'Private'
            ],
        ];

        $post_status_options = '';
        foreach ($post_status_array as $c) {
            $post_status_options .= '<option value="' . $c['name'] . '" ' . ($c['name'] === $post_status ? 'selected="selected"' : '') . '>' . $c['label'] . '</option>';
        }
        settings_fields($this->chain_wire_plugin);
        do_settings_sections($this->chain_wire_plugin);
        ?>

        <!-- load jQuery from CDN -->
        <fieldset>
            <p>Your Category</p>
            <legend class="screen-reader-text"><span><?php _e('Your Category', $this->chain_wire_plugin); ?></span>
            </legend>
            <select class="regular-text" id="<?php echo $this->chain_wire_plugin; ?>-category"
                    name="<?php echo $this->chain_wire_plugin; ?>[category]"
                    value="<?php if (!empty($category)) echo $category; ?>">
                <?php echo $category_options ?>
            </select>
        </fieldset>

        <!-- load jQuery from CDN -->
        <fieldset>
            <p>Default Post Status</p>
            <legend class="screen-reader-text"><span><?php _e('Post Status', $this->chain_wire_plugin); ?></span>
            </legend>
            <select class="regular-text" id="<?php echo $this->chain_wire_plugin; ?>-post_status"
                    name="<?php echo $this->chain_wire_plugin; ?>[post_status]"
                    value="<?php if (!empty($post_status)) echo $post_status; ?>">
                <?php echo $post_status_options ?>
            </select>
        </fieldset>

        <!-- load jQuery from CDN -->
        <fieldset>
            <p>Your Key</p>
            <legend class="screen-reader-text"><span><?php _e('Your Token', $this->chain_wire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->chain_wire_plugin; ?>-token"
                   name="<?php echo $this->chain_wire_plugin; ?>[token]"
                   value="<?php if (!empty($token)) echo $token; ?>"/>
        </fieldset>

        <!-- load jQuery from CDN -->
        <fieldset>
            <p>Your Secret</p>
            <legend class="screen-reader-text"><span><?php _e('Your Secret', $this->chain_wire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->chain_wire_plugin; ?>-secret"
                   name="<?php echo $this->chain_wire_plugin; ?>[secret]"
                   value="<?php if (!empty($secret)) echo $secret; ?>"/>
        </fieldset>

        <p>Additional Options</p>

        <fieldset>
            <legend class="screen-reader-text">
                <span><?php _e('Use client logo instead of featured image', $this->chain_wire_plugin); ?></span>
            </legend>
            <label for="<?php echo $this->chain_wire_plugin; ?>-use_client_image_for_featured_image">
                <input class="regular-text"
                       id="<?php echo $this->chain_wire_plugin; ?>-use_client_image_for_featured_image"
                       type="checkbox"
                       name="<?php echo $this->chain_wire_plugin; ?>[use_client_image_for_featured_image]"
                    <?php if (!empty($use_client_image_for_featured_image)) echo 'checked="checked"'; ?>/>
                <span><?php _e('Use client logo instead of featured image', $this->chain_wire_plugin); ?></span>
            </label>
        </fieldset>

        <fieldset>
            <legend class="screen-reader-text">
                <span><?php _e('Add feature image to post content', $this->chain_wire_plugin); ?></span>
            </legend>
            <label for="<?php echo $this->chain_wire_plugin; ?>-add_feature_image_to_post">
                <input class="regular-text"
                       id="<?php echo $this->chain_wire_plugin; ?>-add_feature_image_to_post"
                       type="checkbox"
                       name="<?php echo $this->chain_wire_plugin; ?>[add_feature_image_to_post]"
                    <?php if (!empty($add_feature_image_to_post)) echo 'checked="checked"'; ?>/>
                <span><?php _e('Add feature image to post content', $this->chain_wire_plugin); ?></span>
            </label>
        </fieldset>

        <!-- load jQuery from CDN -->
        <fieldset class="additional-categories-wrapper" style="display: none">
            <p>Additional Categories</p>
            <legend class="screen-reader-text">
                <span><?php _e('Additional Categories', $this->chain_wire_plugin); ?></span>
            </legend>
            <select class="multiple-select regular-text"
                    multiple="multiple"
                    data-placeholder="Click here to select additional categories"
                    style="max-width: 22rem; width: 100% !important;"
                    name="categories[]">
                <?php echo $category_options ?>
            </select>
            <input type="hidden"
                   name="<?php echo $this->chain_wire_plugin; ?>[additional_categories]"
                   value="<?php if (!empty($additional_categories)) echo $additional_categories; ?>"
                   id="<?php echo $this->chain_wire_plugin; ?>-additional_categories">
        </fieldset>

        <!--        Add feature image to post content-->
        <?php submit_button('Save all changes', 'primary', 'submit', TRUE); ?>

    </form>

</div>
